package com.apress.prospring4.ch2;

public interface MessageProvider {
    String getMessage();
}
