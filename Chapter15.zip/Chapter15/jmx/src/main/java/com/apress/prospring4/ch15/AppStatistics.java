package com.apress.prospring4.ch15;

public interface AppStatistics {
    int getTotalContactCount();
}
