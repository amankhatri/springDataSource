package com.apress.prospring4.ch5;

public class TestBean {
    public void foo() {
        System.out.println("foo()");
    }
}
