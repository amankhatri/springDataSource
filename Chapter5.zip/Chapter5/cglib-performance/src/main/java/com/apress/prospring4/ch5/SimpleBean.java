package com.apress.prospring4.ch5;

public interface SimpleBean {
    void advised();
    void unadvised();
}
