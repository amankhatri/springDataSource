package com.apress.prospring4.ch5;

public class MyDependency {
    public void foo() {
        System.out.println("foo()");
    }

    public void bar() {
        System.out.println("bar()");
    }
}
