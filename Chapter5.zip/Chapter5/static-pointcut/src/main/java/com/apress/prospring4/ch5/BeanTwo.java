package com.apress.prospring4.ch5;

public class BeanTwo {
    public void foo() {
        System.out.println("foo");
    }

    public void bar() {
        System.out.println("bar");
    }
}
