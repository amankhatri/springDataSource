package com.apress.prospring4.ch5;

public class TargetBean {
    private String name;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
