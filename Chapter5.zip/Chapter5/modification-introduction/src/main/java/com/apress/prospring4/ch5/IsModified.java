package com.apress.prospring4.ch5;

public interface IsModified {
    boolean isModified();
}
