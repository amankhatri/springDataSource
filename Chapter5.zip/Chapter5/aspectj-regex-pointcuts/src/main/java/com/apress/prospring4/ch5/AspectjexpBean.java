package com.apress.prospring4.ch5;

public class AspectjexpBean {
    public void foo1() {
        System.out.println("foo1");
    }

    public void foo2() {
        System.out.println("foo2");
    }

    public void bar() {
        System.out.println("bar");
    }
}
