package com.apress.prospring4.ch3;

public class Encyclopedia {
    
}