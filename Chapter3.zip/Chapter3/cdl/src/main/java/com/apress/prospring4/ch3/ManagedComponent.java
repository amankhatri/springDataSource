package com.apress.prospring4.ch3;

public interface ManagedComponent {
    void performLookup(Container container);  
}
