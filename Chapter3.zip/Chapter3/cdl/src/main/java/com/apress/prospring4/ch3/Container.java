package com.apress.prospring4.ch3;

public interface Container {
    Object getDependency(String key);
}
