package com.apress.prospring4.ch3;

public class Dependency {
	@Override
	public String toString() {
		return "Hello from " + getClass();
	}
}
