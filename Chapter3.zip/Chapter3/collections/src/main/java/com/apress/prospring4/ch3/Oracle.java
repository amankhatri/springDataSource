package com.apress.prospring4.ch3;

public interface Oracle {
    String defineMeaningOfLife();
}
