package com.apress.prospring4.ch3;

public class SimpleTarget {
    private String val;
    
    public void setVal(String val) {
        this.val = val;
    }
    
    public String getVal() {
        return val;
    }
}
