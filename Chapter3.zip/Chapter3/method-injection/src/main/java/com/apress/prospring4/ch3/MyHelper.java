package com.apress.prospring4.ch3;

public class MyHelper {
    public void doSomethingHelpful() {
        // do something! 
    }
}
