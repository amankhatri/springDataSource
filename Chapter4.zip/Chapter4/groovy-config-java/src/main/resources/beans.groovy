package com.apress.prospring4.ch4

beans {
    contact(Contact, firstName: 'Chris', lastName: 'Schaefer', age: 32)
}
