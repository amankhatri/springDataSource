package com.apress.prospring4.ch4;

import java.util.List;

public interface FoodProviderService {
    List<Food> provideLunchSet();
}
