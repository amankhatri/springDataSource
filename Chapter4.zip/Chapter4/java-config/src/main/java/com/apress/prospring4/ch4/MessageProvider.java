package com.apress.prospring4.ch4;

public interface MessageProvider {
    String getMessage();
}
