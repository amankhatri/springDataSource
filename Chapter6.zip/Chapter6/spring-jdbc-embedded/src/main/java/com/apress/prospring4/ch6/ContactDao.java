package com.apress.prospring4.ch6;

public interface ContactDao {
    String findFirstNameById(Long id);
}

