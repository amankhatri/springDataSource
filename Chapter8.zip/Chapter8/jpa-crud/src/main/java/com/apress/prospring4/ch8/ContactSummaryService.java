package com.apress.prospring4.ch8;

import java.util.List;

public interface ContactSummaryService {
    List<ContactSummary> findAll();
}
