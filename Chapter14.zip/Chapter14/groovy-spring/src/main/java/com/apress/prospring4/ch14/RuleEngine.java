package com.apress.prospring4.ch14;

public interface RuleEngine {
    void run(Rule rule, Object object);
}
