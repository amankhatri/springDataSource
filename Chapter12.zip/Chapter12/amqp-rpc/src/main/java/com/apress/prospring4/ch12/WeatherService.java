package com.apress.prospring4.ch12;

public interface WeatherService {
    String getForecast(String stateCode);
}
